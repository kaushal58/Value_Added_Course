<?php
// Database connection
$servername = "localhost";
$username = "root";  // your DB username
$password = "";  // your DB password
$dbname = "user_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

$message = "";

// Handle Registration
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
    $reg_username = $_POST['reg_username'];
    $reg_email = $_POST['reg_email'];
    $reg_password = password_hash($_POST['reg_password'], PASSWORD_DEFAULT);

    // Check if username already exists
    $sql_check = "SELECT * FROM users WHERE username='$reg_username'";
    $result_check = $conn->query($sql_check);

    if ($result_check->num_rows > 0) {
        $message = "Username already exists!";
    } else {
        // Insert registration data
        $sql_insert = "INSERT INTO users (username, email, password) VALUES ('$reg_username', '$reg_email', '$reg_password')";
        
        if ($conn->query($sql_insert) === TRUE) {
            $message = "Registration successful! <br> You can now log in.";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}

// Handle Login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $login_username = $_POST['login_username'];
    $login_password = $_POST['login_password'];

    // Check if the user exists
    $sql_login = "SELECT * FROM users WHERE username='$login_username'";
    $result_login = $conn->query($sql_login);

    if ($result_login->num_rows > 0) {
        $row = $result_login->fetch_assoc();
        
        // Verify password
        if (password_verify($login_password, $row['password'])) {
            $_SESSION['username'] = $row['username'];
            $message = "Login successful! Welcome, " . $_SESSION['username'];
        } else {
            $message = "Invalid password!";
        }
    } else {
        $message = "User not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration and Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .message {
            text-align: center;
            margin-top: 20px;
            color: #d9534f;
        }
        .message.success {
            color: #5bc0de;
        }
        .toggle-btn {
            display: block;
            margin-top: 10px;
            text-align: center;
            color: #007bff;
            cursor: pointer;
        }
        .toggle-btn:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Registration & Login</h2>
    
    <div class="message <?php echo isset($message) && strpos($message, 'successful') !== false ? 'success' : ''; ?>">
        <?php echo $message; ?>
    </div>

    <!-- Registration Form -->
    <form method="POST" action="register-login.php">
        <div class="form-group">
            <label for="reg_username">Username:</label>
            <input type="text" id="reg_username" name="reg_username" required>
        </div>
        <div class="form-group">
            <label for="reg_email">Email:</label>
            <input type="email" id="reg_email" name="reg_email" required>
        </div>
        <div class="form-group">
            <label for="reg_password">Password:</label>
            <input type="password" id="reg_password" name="reg_password" required>
        </div>
        <input type="submit" name="register" value="Register">
        <span class="toggle-btn" onclick="toggleForms()">Already have an account? Login</span>
    </form>

    <!-- Login Form -->
    <form method="POST" action="register-login.php" style="display:none;">
        <div class="form-group">
            <label for="login_username">Username:</label>
            <input type="text" id="login_username" name="login_username" required>
        </div>
        <div class="form-group">
            <label for="login_password">Password:</label>
            <input type="password" id="login_password" name="login_password" required>
        </div>
        <input type="submit" name="login" value="Login">
        <span class="toggle-btn" onclick="toggleForms()">Don't have an account? Register</span>
    </form>
</div>

<script>
    function toggleForms() {
        let registerForm = document.querySelector('form[action="register-login.php"]:nth-of-type(1)');
        let loginForm = document.querySelector('form[action="register-login.php"]:nth-of-type(2)');
        
        if (registerForm.style.display === 'none') {
            registerForm.style.display = 'block';
            loginForm.style.display = 'none';
        } else {
            registerForm.style.display = 'none';
            loginForm.style.display = 'block';
        }
    }
</script>

</body>
</html>

<?php
$conn->close();
?>
